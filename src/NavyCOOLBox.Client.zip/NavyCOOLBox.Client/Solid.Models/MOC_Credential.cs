﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solid.Models
{
	public class MOC_Credential
	{

		public int MOC_ID { get; set; }
		public string ServiceTitle { get; set; }
		public string ServiceOccupationCode { get; set; }
		public string URL { get; set; }
	}
}
