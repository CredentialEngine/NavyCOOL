﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NavyCOOLBox.Models
{
	public class Address
	{
        public string CA_StreetAddress1 { get; set; }
        public string CA_StreetAddress2 { get; set; }
        public string CA_City { get; set; }
        public string CA_State { get; set; }
        public string CA_Zip { get; set; }
        public string CA_Country { get; set; }
    }
}
